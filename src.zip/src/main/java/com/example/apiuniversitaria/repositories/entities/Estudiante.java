package com.example.apiuniversitaria.repositories.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Estudiante {

    private String id;
    private String nombre;
    private String documento;
    private String email;
    private int edad;
}
