package com.example.apiuniversitaria.controllers;

import com.example.apiuniversitaria.controllers.dto.CreateEstudianteRequest;
import com.example.apiuniversitaria.controllers.dto.EstudianteResponse;
import com.example.apiuniversitaria.repositories.entities.Estudiante;
import com.example.apiuniversitaria.services.EstudianteService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/estudiante")
@Tag(name = "Estudiantes", description = "Gestión de estudiantes de la universidad")
public class EstudianteController {

    private final EstudianteService estudianteService;

    public EstudianteController(EstudianteService estudianteService){
        this.estudianteService = estudianteService;
    }

    @Operation(summary = "Obtener todos los estudiantes",
            description = "Retorna una lista de todos los estudiantes")
    @ApiResponse(responseCode = "200", description = "Lista de estudiantes obtenida exitosamente")
    @GetMapping
    public ResponseEntity<List<EstudianteResponse>> listar(){
        return ResponseEntity
                .status(HttpStatus.OK)
                .body(estudianteService.listar());
    }

    @GetMapping("/{documento}")
    public ResponseEntity<Void> buscar(@PathVariable String documento){
        estudianteService.borrar(documento);
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }

    @PostMapping
    public ResponseEntity<Estudiante> crear(@RequestBody CreateEstudianteRequest estudiante){
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(estudianteService.crear(estudiante));
    }

    @PutMapping("/{documento}")
    public ResponseEntity<Estudiante> actualizar(@PathVariable String documento, @RequestBody Estudiante estudiante){
        return ResponseEntity
                .status(HttpStatus.OK)
                .body(estudianteService.actualizar(documento, estudiante));
    }

    @DeleteMapping("/{documento}")
    public ResponseEntity<Estudiante> borrar(@PathVariable String documento){;
        return ResponseEntity
                .status(HttpStatus.OK)
                .body(estudianteService.buscar(documento));
    }
}
