package com.example.apiuniversitaria.services;

import com.example.apiuniversitaria.controllers.dto.CreateEstudianteRequest;
import com.example.apiuniversitaria.controllers.dto.EstudianteResponse;
import com.example.apiuniversitaria.repositories.entities.Estudiante;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
public class EstudianteServiceImpl implements EstudianteService {

    private final List<Estudiante> estudianteList;

    public EstudianteServiceImpl(List<Estudiante> estudianteList){
        this.estudianteList = estudianteList;
    }

    @Override
    public List<EstudianteResponse> listar() {

        return estudianteList.stream().map(
                (estudiante -> {
                    EstudianteResponse response = new EstudianteResponse();
                    response.setId(estudiante.getId());
                    response.setDocumento(estudiante.getDocumento());
                    response.setEmail(estudiante.getEmail());
                    response.setNombre(estudiante.getNombre());
                    return response;
                })).toList();
    }

    @Override
    public Estudiante crear(CreateEstudianteRequest
                                        estudianteRequest) {

        Estudiante estudiante = new Estudiante();
        estudiante.setId(UUID.randomUUID().toString());
        estudiante.setDocumento(estudianteRequest.getDocumento());
        estudiante.setEdad(estudianteRequest.getEdad());
        estudiante.setNombre(estudianteRequest.getNombre());
        estudiante.setEmail(estudianteRequest.getEmail());

        estudianteList.add(estudiante);
        return estudiante;
    }

    @Override
    public Estudiante actualizar(String documento, Estudiante estudiante) {

        List<Estudiante> listaActualizada = new ArrayList<>();

        for(int i = 0; i < estudianteList.size(); i++){
            if(estudianteList.get(i).getDocumento().equalsIgnoreCase(documento)){
                listaActualizada.add(estudiante);
                break;
            }
            listaActualizada.add(estudianteList.get(i));
        }

        estudianteList.clear();
        estudianteList.addAll(listaActualizada);

        return estudiante;
    }

    @Override
    public void borrar(String documento) {
        for(int i = 0; i < estudianteList.size(); i++){
            if(estudianteList.get(i).getDocumento().equalsIgnoreCase(documento)){
                estudianteList.remove(i);
                break;
            }
        }
    }

    @Override
    public Estudiante buscar(String documento) {
        for(int i = 0; i < estudianteList.size(); i++){
            if(estudianteList.get(i).getDocumento().equalsIgnoreCase(documento)){
                return estudianteList.get(i);
            }
        }
        return null;
    }
}
